# **简介**

**miwear-sdk** 是一个和硬件平台无关的中间层，它帮助厂商完成小米穿戴的设备接入，蓝牙数据的传输，获取 mibeacon 数据等功能。sdk 由纯 C 代码实现，不依赖运行环境，在 RTOS 以及裸机环境中均可工作。

> sdk支持ble和spp两种蓝牙模式，针对两种模式的不同接口会有特殊的说明，若无特殊说明，则对两种模式通用。

## **绑定和登录**

穿戴设备需通过安全的协议，才可以接入到小米穿戴，完成绑定过程。绑定成功后可以通过小米穿戴 App 进行控制。

小米穿戴依靠 Bluetooth 连接，利用小米服务 mi service 进行数据传输。认证过程中，双方会交换公钥和证书信息，同时还会进行 ECDH、HKDF 等运算。整个过程耗时较长，为了不阻塞系统的其他功能，在接收回调中通过状态机完成指令收发功能，执行的结果通过回调函数通知应用层。

绑定登录过程由 mi service 里 PROTO_RX 特征值写事件 (ATT WRITE) 触发。

##  **厂商需要完成的工作**

> 注：具体的例子和详细注释在 demo 文件夹，建议仔细阅读。

### **需要实现的方法和配置**

因为 sdk 不依赖运行环境，所以有一些依赖平台的接口、加密库或者与厂商产品定义相关的配置需要厂商自己来实现。

- miwear_api_port.c，是需要各厂商平台实现的方法类，注释请参考头文件定义`miwear_api.h`和 demo 文件夹注释说明。
- miwear_config.c 中有一个配置，需要厂商根据自己的产品定义实现 miwear_config。
  - 配置全局的 log 等级
  - 用户需要申请的 product id，对于一设备一 pid 的情况，可以直接访问 miwear_config 结构体修改 pid
  - 用户需要根据设备实际情况选择 verify mode
  - 用户需要根据设备实际情况选择 oob mode，目前支持的组合有
    - MIWEAR_VERIFY_MODE_PSK + MIWEAR_OOB_MODE_NO_OOB
    - MIWEAR_VERIFY_MODE_PSK + MIWEAR_OOB_MODE_NUMERIC_COMPARISON
    - MIWEAR_VERIFY_MODE_PSK + MIWEAR_OOB_MODE_BUTTON_CONFIRM
    - MIWEAR_VERIFY_MODE_LOCAL + MIWEAR_OOB_MODE_BUTTON_CONFIRM
    - MIWEAR_VERIFY_MODE_LOCAL + MIWEAR_OOB_MODE_DYNAMIC_CODE
    - MIWEAR_VERIFY_MODE_LOCAL + (MIWEAR_OOB_MODE_BUTTON_CONFIRM | MIWEAR_OOB_MODE_DYNAMIC_CODE)

### **需要进行的初始化**

- sdk初始化
  - 通过调用`miwear_bluetooth_init()` 函数完成sdk的初始化

初始化sdk，需要传入处理接收从穿戴 APP 推送过来的数据的回调函数，sdk 对穿戴 APP 发送过来的 proto等数据进行并包等处理会通过此回调通知给平台。 对于 proto 数据，回调参数 param 包含了解包后的 proto 数据和 proto 原始数据。

- 初始化调度器
  - 调用`miwear_scheduler_init() `即可，用户需要传入自定义的回调函数，完成对指定事件的处理
- 初始化解锁及回调（ble模式）
  - 支持解锁小米手机/笔记本功能的设备，调用`miwear_unlock_init()`初始化解锁功能并传入用户自定义回调函数，处理解锁事件

### **发送 mibeacon 广播**

小米穿戴设备通过广播来表明自己的存在，等待着被连接。

- 小米服务
  - 为了建立 ble 连接，设备广播中需要包含小米服务数据 <ServiceData>(0x16) UUID 0xFE95，这样设备才会被小米穿戴 App 发现
  - sdk 提供接口`mibeacon_mi_service_data_get`用来获取小米服务 mibeacon 的广播数据

- 解锁服务

  > 当前解锁手机/笔记本功能，依赖于设备先完成 ble bond，这样手机/笔记本的 mac 地址才是可以解析的某个固定值（public address）。

  - 为了支持解锁小米手机/笔记本的功能，设备广播中需要包含小米解锁服务 <ServiceData>(0x16) UUID 0xFDAB
  - sdk 提供接口`mibeacon_unlock_service_data_get`用来获取解锁服务的广播数据

### **用户回调通知对应事件给 sdk**

#### 注册 GATT Service

- miwear_type.h 中已经定义了所有支持属性的默认的16位的 UUID，如使用 sdk 中默认的 uuid 可直接使用进行 GATT Service 的注册，不需要的话自行定义即可
- GATT Service 注册成功后，需要调用回调接口`miwear_arch_event_callback`告诉 sdk 各属性 UUID 对应的 charateristic handle
- charateristic handle 是 sdk 区分各厂商不同属性通道的句柄

#### 更新连接状态

- ble模式连接事件，连接成功、断开以及更新连接参数事件通过`miwear_gap_event_callback`回调给 sdk
- spp模式连接事件，连接成功还是断开事件通过`miwear_spp_service_update_connect_status`通知给 sdk

#### 接收蓝牙数据

- ble模式接收数据，平台需要将 sdk 中对应 uuid 通道的数据通过`miwear_gatts_event_callback`回调给 sdk
- spp模式接收数据，平台需要将接收到的数据通过`miwear_spp_service_receive_data`通知给 sdk

### **sdk 回调通知对应事件给用户**

#### **绑定登录流程事件**

- MIWEAR_SCHD_EVT_REG_START: 绑定（注册）流程开始时，收到此事件，无参数
- MIWEAR_SCHD_EVT_REG_RESTART: 绑定（注册）流程从中间步骤重新开始时，收到此事件，无参数
- MIWEAR_SCHD_EVT_REG_SUCCESS: 绑定（注册）流程成功后，收到此事件，无参数
- MIWEAR_SCHD_EVT_REG_FAILED: 绑定（注册）流程失败时，收到此事件， p_event->data.fail_reason 参数包含失败原因
  - FAIL_REASON_CONFIRM_TIMEOUT -收到 MIWEAR_SCHD_EVT_BIND_USER_CONFIRM 事件后用户未在指定时间内操作，发生了超时
  - FAIL_REASON_USER_CANCEL - 收到 MIWEAR_SCHD_EVT_BIND_USER_CONFIRM 事件后用户选择了取消
  - FAIL_REASON_APP_CANCEL - APP 主动取消接下来的操作
  - FAIL_REASON_FSM_TIMEOUT - 状态机发生了超时
  - FAIL_REASON_DISCONNECT - 蓝牙连接已断开
  - FAIL_REASON_UNKNOWN - 未知错误，比如内存申请失败等
- MIWEAR_SCHD_EVT_USER_CONFIRM: 支持用户确认的绑定（注册）流程有此事件，用户需要调用 miwear_schd_user_confirm/miwear_schd_user_cancel 确认或取消；支持显示 oob 数字和 app 比对的，p_event->data.oob 参数包含 6 位数字。用户需要异步处理显示数字并确认的逻辑，防止阻塞 ble 协议栈
- MIWEAR_SCHD_EVT_ADMIN_LOGIN_START: 登录（认证）流程开始时，收到此事件，无参数
- MIWEAR_SCHD_EVT_ADMIN_LOGIN_RESTART: 登录（认证）流程从中间步骤重新开始时，收到此事件，无参数
- MIWEAR_SCHD_EVT_ADMIN_LOGIN_SUCCESS: 登录（认证）流程成功后，收到此事件，无参数
- MIWEAR_SCHD_EVT_ADMIN_LOGIN_FAILED: 登录（认证）流程失败时，收到此事件， p_event->data.fail_reason 参数包含失败原因
  - FAIL_REASON_FSM_TIMEOUT - 状态机发生了超时
  - FAIL_REASON_DISCONNECT - 蓝牙连接已断开
  - FAIL_REASON_UNKNOWN - 未知错误，比如内存申请失败等
- MIWEAR_SCHD_EVT_ADMIN_LOGIN_DEVICE: 本地绑定（注册）或者登录（认证）流程结束时，收到此事件，p_event->data.device 参数包含对端设备的信息
  > 说明：app_capability是表示app具有的能力，设备端可以根据每个bit的含义做对应的处理
  app_capability & 0x00000001: current region support alexa
  app_capability & 0x00000002: send phone call notification
- MIWEAR_SCHD_EVT_DID_REQ: 绑定（注册）流程获取设备did时，收到此事件，无参数。用户需要调用 miwear_schd_did_result 传入 did 结果
- MIWEAR_SCHD_EVT_PSK_HMAC_REQ: PSK方式绑定（注册）流程获取设备 psk-hmac 时，收到此事件，p_event->data.hmac_in 参数包含传入的原始数据。用户需要调用 miwear_schd_psk_hmac_result 通知 sdk psk-hmac 计算结果

#### **解锁事件**

- MIWEAR_UNLOCK_EVT_USER_CONFIRM: 添加新的解锁目标设备时，收到此事件，参数是目标设备类型。用户需要调用 miwear_unlock_add_confirm/miwear_unlock_add_cancel 确认或取消，且需要异步处理，防止阻塞 ble 协议栈
- MIWEAR_UNLOCK_EVT_CONFIRM_TIMEOUT: 收到 MIWEAR_UNLOCK_EVT_USER_CONFIRM 事件后用户未在指定时间内操作，发生了超时，参数是目标设备类型
- MIWEAR_UNLOCK_EVT_CONNECTED: 解锁目标设备连接时，收到此事件，参数是目标设备类型。用户可以选择处理解锁广播相关的逻辑
- MIWEAR_UNLOCK_EVT_DISCONNECTED: 解锁目标设备断开连接时，收到此事件，参数是目标设备类型。用户可以选择处理解锁广播相关的逻辑

## **发送数据给穿戴 APP**

**对于ble和spp来说，发送数据的接口是统一的**。sdk内部实现了一个待发送数据的优先级队列，目前优先级为 **VOICE > PROTO > FILE**。发送文件也实现成了一个队列，因此接入方在发送数据或文件时，可以连续调用下面的API，sdk在完成对应数据或文件的发送后，会通过回调函数通知给接入方，result 0 代表发送成功，负值代表失败。值得一提的是，对于文件发送，只要实现了对应的接口，并不要求一定存在文件系统。

#### sdk提供的API

1. 送 proto 数据

   int miwear_proto_data_send()

2. 发送 voice 数据（用于小爱同学等）

   - 音频数据开始

   int miwear_voice_start()

   - 发送音频数据

   int miwear_voice_data_send()

   - 音频数据结束

   int miwear_voice_data_end()

   - 退出音频识别

   int miwear_voice_exit()

3. 发送文件

   int miwear_file_enqueue()

用户传入待发送的文件类型，文件id，header，文件大小以及发送状态回调函数。sdk 会根据文件id打开并读取指定文件（这部分 port 接口需要用户实现），完成文件的上传。

#### 需要实现的接口

1. int miwear_file_open(miwear_file_type_t type, uint8_t* id, size_t id_len, int index, file_open_cb_t open_cb)

用于异步打开文件。其中 index 由 sdk 内部维护，用于区分不同文件。当接入方打开了指定 type & id 的文件后，需要调用**open_cb**告知 sdk 结果。index 是接口传入的 index，handle 是由接入方维护可以唯一标识某个文件的句柄，此句柄会用于后续操作。handle 为负代表打开出错。

2. int miwear_file_read(int handle, uint8_t* buf, size_t len, file_read_cb_t read_cb)

用于异步读取文件内容。handle 是 open 拿到的 handle，buf 是用于填充数据的缓冲区，len是sdk期待读取的长度。读取结果通过**read_cb**通知 sdk，result 代表实际读取的长度。result为负代表读取出错。

3. int miwear_file_close(int handle, file_close_cb_t close_cb)

用于关闭文件，目前**close_cb**未用到。

> 接入方提供的接口要保证是异步操作，防止sdk阻塞。

## 大数据传输

mass数据的相关处理由sdk接管，包括表盘、OTA、GNSS等数据。对于接入方来说不需要关心mass数据的协议部分，但接入方需要提供sdk对mass处理需要的API。目前sdk支持两种类型的mass数据传输：

- mass数据的续传（MASS_PREPARE_TYPE_TRANSPORT_RESUME）
- mass数据的新数据传输（MASS_PREPARE_TYPE_TRANSPORT_RESTART）

无论是哪种类型的mass数据传输（取决于穿戴App发起的mass传输请求），sdk都会通过miwear_mass_prepare向接入方发起mass数据的传输请求。

- 对于数据的续传来说，需要返回文件续传的信息。
- 对于新数据传输来说，接入方需要重新返回一个新的mass数据信息，sdk不会走mass续传流程。接口参数的描述请参照miwear_api.h以及demo。

> 接入方提供的接口要保证是异步操作，防止sdk阻塞。

#### 需要实现的接口

1. sdk发起prepare请求

`int miwear_mass_prepare(miwear_mass_prepare_type_t prepare_type, uint8_t mass_type, uint8_t* id, size_t id_len, size_t size, int index, void* md5_context, uint8_t support_compress_mode, prepare_cb_t prepare_cb);`

无论prepare是否成功，接入方都需要调用**prepare_cb**将执行结果返回给sdk，并将index原值带回，index是sdk内部维护，用于支持多个mass数据的传输。如果是续传请求，则需要回复给sdk mass数据的续传信息，如果是新数据传输，则返回一个新mass数据信息。size用来表示要写入数据的大小，id用来表示mass数据的md5。（id是mass数据的唯一标识，接入方可以通过id来区分不同的mass数据）

2. sdk发起写入mass数据的请求

`int miwear_mass_write(int handle, uint8_t* buf, size_t buf_len, size_t packet_len_written, size_t packet_len_total, mass_write_cb_t write_cb);`

handle是通过prepare_cb返回的mass句柄，用来与prepare请求时的mass数据关联。无论写入是否成功，接入方都需要调用**write_cb**将执行结果返回给sdk，并将handle原值带回。

3. sdk发起上报写入mass数据的结果

`int miwear_mass_finish(int handle, int result);`

handle是通过prepare_cb返回的mass句柄，用来与prepare请求时的mass数据关联，result请参照miwear_mass_finish_result_t结构。

4. md5初始化

`void miwear_md5_init(void** md5_context);`

5. md5更新

`void miwear_md5_update(void* md5_context, uint8_t* buf, uint32_t len);`

6. md5结果

`void miwear_md5_final(void* md5_context, uint8_t result[16]);`

## AMS服务

sdk支持对AMS服务的处理，sdk将处理后的结果转换成与Android一样的Media proto buffer消息并上报给上层应用，从而简化了上层应用的处理（可以参照Protocol Buffer协议 - Media）。接入方实现发现AMS服务的流程以及character订阅的流程，sdk处理订阅的消息。接口参数的描述请参照miwear_api.h以及demo。

#### sdk提供的API

1. 发现所有属性character后将对应的character value handle传递给sdk

`void miwear_media_ams_evt_handler(miwear_media_ams_evt_t* p_evt);`

对于MIWEAR_MEDIA_AMS_EVT_DISCOVERY_COMPLETE事件来说，data区的结构为`miwear_media_ams_service_t`，详见miwear_type.h。

2. 请求播放信息

`void miwear_media_player_request(void);`

3. 播放控制

`void miwear_media_player_control(uint8_t command, uint8_t volume);`

#### 需要实现的接口

1. ams character写入请求

`void miwear_media_ams_char_write(uint16_t conn_handle, uint16_t char_handle, uint8_t* data, uint16_t data_len, uint8_t count);`

2. ams character读取请求

`void miwear_media_ams_char_read(uint16_t conn_handle, uint16_t char_handle, uint16_t offset);`

当执行写入操作或读取某个属性的操作时，如果收到了错误的消息码，请接入方自行处理（请检查是否已经订阅了相关的属性），无需透传给sdk。

## ANCS 服务

sdk支持对ANCS服务的处理，sdk内部把从ANCS服务读取到的通知转换成和Android相同格式的Notification protobuf，供接入方使用，也可以使用统一的接口对通知进行操作，比如移除通知等。接入方无需关心Android和iOS的区别（可以参照Protocol Buffer协议 - Notification）。

1. 接入方需要自己实现对ANCS服务和属性的发现和订阅。

2. 实现如下接口

void miwear_ancs_control_point_write()

3. sdk提供的API在收到对应属性的notification时，调用如下两个接口

void miwear_ancs_notification_source_receive()

void miwear_ancs_data_source_receive()

4. 接入方可以调用的ancs相关api，详见 miwear_api.h

## **sdk目录结构**

```
.
├── CHANGELOG.md              # sdk 版本更新的 changelog
├── include                   # 平台需要添加的 sdk 里的头文件
│  ├── miwear_api.h
│  ├── miwear_config.h
│  ├── miwear_type.h
│  └── pb                     # 和 protoBuf 相关的头文件
│    ├── nanopb.pb.h
│    ├── pb_common.h
│    ├── pb_decode.h
│    ├── pb_encode.h
│    ├── pb.h
│    ├── wear_account.pb.h
│    ├── wear_aivs.pb.h
│    ├── wear_alexa.pb.h
│    ├── wear_calendar.pb.h
│    ├── wear_clock.pb.h
│    ├── wear_common.pb.h
│    ├── wear_factory.pb.h
│    ├── wear_fitness.pb.h
│    ├── wear_gnss.pb.h
│    ├── wear_lpa.pb.h
│    ├── wear_market.pb.h
│    ├── wear_media.pb.h
│    ├── wear_nfc.pb.h
│    ├── wear_notification.pb.h
│    ├── wear_packet_encode.h
│    ├── wear.pb.h
│    ├── wear_stock.pb.h
│    ├── wear_system.pb.h
│    ├── wear_watch_face.pb.h
│    └── wear_weather.pb.h
├── lib
│  ├── miwear-sdk-apollo3_x.y.z.a         # sdk 静态库 miwear-sdk-(port)_$(version).a 不同平台特定编译链
│  └── miwear-sdk-apollo3-nanopb_x.y.z.a  # protoBuf 相关静态库
├── miwear_api_port.c                     # 用户需要实现的 port 层接口
├── miwear_config.c                       # 用户需要实现的配置项
└── README.md                             # miwear-sdk 接入说明
```
