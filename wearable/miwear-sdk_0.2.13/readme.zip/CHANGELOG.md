### miwear-sdk-0.2.13 (2022.6.7)
1. ancs解析器bug修复和优化
2. ancs队列长度限制为20，过滤pre exist消息
3. 简化ancs通知应用列表，和其他产品保持一致
4. login成功返回对端设备信息
5. mass传输增加暂停和取消操作
6. 修复spp模块double free问题
7. 增加device capability配置
8. 更新 protobuf 文件

### miwear-sdk-0.2.12 (2022.4.13)
1. iOS 可通过 pb 指令触发 ble 配对
2. auth pb 发送成功清 busy flag
3. 修复文件发送失败未 close 的 bug
4. 修复文件发送 context 未清空的 bug
5. sdk 增加对 md5 校验的可选功能
6. 简化 ancs 通知应用列表，区分国内海外
7. 更新 protobuf 文件
8. 更新mass传输超时时间到12秒

### miwear-sdk-0.2.11 (2022.3.28)
1. 延长ancs parser超时时间，优化ancs接口有效性判断逻辑
2. 小爱接口支持tts参数
3. 修复数据队列空时未检查文件队列导致文件不启动发送的bug
4. 连接新手机广播内容修改
5. 修复分包和文件传输double free问题
6. 通知全局开关关闭时，不解析ancs消息
7. 更新 protobuf 文件

### miwear-sdk-0.2.10 (2022.2.22)
1. 修复分包double free问题
2. 修复穿戴断开连接判断错误的bug
3. mass增加互斥锁保护

### miwear-sdk-0.2.9 (2022.2.15)
1. 绑定新设备校验user id
2. 优化日志打印，将一些log调整为verbose级别
3. 更新 protobuf 文件
4. 修复ancs定时器误删bug

### miwear-sdk-0.2.8 (2022.1.26)
1. 修复断点续传的bug
2. 修改spp发送接口为异步发送
3. 优化日志打印功能，将一些关键信息提高到info级别

### miwear-sdk-0.2.7 (2022.1.15)
1. 修复优先级队列bug，非文件数据总是可以打断文件传输
2. 优化分包模块，更友好的debug log
3. 更新 protobuf 文件

### miwear-sdk-0.2.6 (2022.1.11)
1. 通过异步方式获取did（psk/local）和hmac（仅psk）
2. 更新 protobuf 文件

### miwear-sdk-0.2.5 (2021.12.27)
1. psk bind增加no oob mode
2. companion device新增app capability
3. 更新 protobuf 文件

### miwear-sdk-0.2.4 (2021.12.20)
1. 修复发包时传输层选择错误的bug
2. 更新 protobuf 文件
3. 自动化同步sdk脚本（内部用）

### miwear-sdk-0.2.3 (2021.12.11)
1. 更新 protobuf 文件

### miwear-sdk-0.2.2 (2021.12.1)
1. 去掉发送重试逻辑
2. 增加互斥锁porting接口
3. 增加音频结束和退出接口
4. 去掉文件传输超时，增加打印
5. 修复session多线程调用的bug
6. 修复连接状态不更新的bug
7. 完善ble spp同时连接时的处理
8. 细化了分包状态机
9. 统一miwear malloc/free
10. 更新 protobuf 文件

### miwear-sdk-0.2.1 (2021.10.09)
1. 对外统一SDK初始化接口
2. 完善对外的接口描述和demo

### miwear-sdk-0.2.0 (2021.9.30)
1. 实现文件上下行逻辑和接口
2. 增加ancs服务解析和接口
3. 增加ams服务解析和接口
4. ble多连接断连处理
5. 修复分包多线程问题
6. 同时支持ble和spp作为传输层
7. 模块化编译
8. 更新 protobuf 文件

### miwear-sdk-0.1.2 (2021.7.16)
1. 修复解锁 pb 误识别的 bug
2. 更新三方应用、联系人相关 protobuf 文件
3. 修复 spp 传输的 bug

### miwear-sdk-0.1.1 (2021.5.28)
1. 更新protobuf文件
2. 增加c/c++混编
3. 更新ble模块的接口函数名

### miwear-sdk-0.1.0 (2021.5.7)
1. 增加 local bind key 踢出逻辑，踢掉最老的
2. 增加解锁使能处理逻辑，解锁事件回调接口
3. 完善状态机对断开连接、发送失败等异常情况的处理
4. 更新 protobuf 文件
5. 增加必要的 log

### miwear-sdk-0.0.9 (2021.4.9)
1. 修复有符号整形左移运算存在的 undefined behavior
2. schd event 增加 fail reason，去掉无意义的事件类型
3. 修复 nrf52832 编译 CFLAGS 乱码问题

### miwear-sdk-0.0.8 (2021.3.31)
1. 修复 bind/login 状态机存在的内存泄漏问题
2. miwear config 可以修改，主要是支持更新 pid
3. 更新 NFC 相关 protobuf 文件

### miwear-sdk-0.0.7 (2021.3.23)
1. 通用 sdk，只需要一个通用 sdk lib 文件，根据 `miwear_config` 中的配置执行对应的协议
2. 增加 demo 例程文件夹，提供了详细的注释说明
3. did 等参数默认空字符串
4. ble 分包增加蓝牙断开连接状态的回调
5. ble 增加 sensor data 通道的支持
6. 修复 timer 创建失败导致的非法访问问题

### miwear-sdk-0.0.6 (2021.3.2)
1. protobuf 相关逻辑单独编译成静态库，供第三方使用
2. `miwear_write_handler_t` 回调给用户 proto 原始数据
3. 修复 bug：调用 `miwear_device_oob_get` 未初始化 buffer len
4. 对于不支持 confirm/cancel 的设备，`miwear_schd_user_confirm` 和 `miwear_schd_user_cancel` 实现为空函数
5. 增加更多调试 log

### miwear-sdk-0.0.5 (2021.2.22)
1. psk bind、local bind 和 login 采用新的协议，内部实现进行了重构
2. 存储接口采用 key-value 形式，新增获取设备 oob 信息的接口
3. `MIWEAR_SCHD_EVT_USER_CONFIRM` 和 `MIWEAR_SCHD_EVT_ADMIN_LOGIN_DEVICE` 事件新的回调参数
4. 重构了单元测试代码，可测试不同的协议类型
5. 修复了分包的内存泄漏
6. Makefile 基于不同的设备类型，编译不同的 lib 文件

### miwear-sdk-0.0.4 (2021.1.18)
1. 修复内存申请失败的情况下，free野指针的问题
2. makefile增加esp32类型
3. 文件、变量和函数重命名`mible`->`miwear`，避免和其他sdk冲突
4. 修复潜在的变量/缓冲区溢出bug，如mtu size大于255

### miwear-sdk-0.0.3
1. 重命名GATT Service和Charateristic UUID的宏定义，增加解锁服务的Service和Charateristic UUID；
2. SDK内部支持多个GATT Service注册，GATT Service 注册结果回调`miwear_arch_event_callback`参数定义修改：类型`miwear_gatts_srv_handle_t`指针返回；
3. 优化给手机穿戴APP发送数据的接口：`miwear_gatt_notify`；
4. 蓝牙数据接收事件`MIWEAR_GATTS_EVT_WRITE`，其对应参数`miwear_gatts_evt_param_t`中添加：对端public 的Mac 地址`peer_public_addr`；
5. 初始化方法`miwear_init`重命名为`miwear_srv_init`；去掉接收手机穿戴APP发送数据的回调注册方法`miwear_gatt_data_rcvr_register`，改由从`miwear_srv_init`参数传入，参数回调`miwear_write_handler_t`必须处理，否则无法处理穿戴APP推送过来的数据；
6. `miwear_gatt_notify`,`miwear_write_handler_t`, `miwear_schd_event_handler_t`等与sdk交互的事件添加conn handle；
7. `miwear_api_port.c`是需要平台实现的方法，最新改动是加密相关api也由用户实现，方法注释见`miwear_api.h`
8. 修复了`miwear_session_encrypt/miwear_session_decrypt` ilen溢出的问题

### miwear-sdk-0.0.2(2020.12.02)
1. 对外的接口调整，如`miwear_scheduler_init`去掉interval参数，`miwear_hexdump_printf`新加了参数p_name；
2. 添加了蓝牙传输单包分包的逻辑；
3. 去掉auth的uuid，通过proto通道并新增auth的cmd数据类型来区分auth和普通的proto数据；
4. 分包逻辑支持单通道的收和发；
5. 去掉event monitor定时轮询，功耗更友好；
6. 接收数据不匹配、绑定成功事件，设备端返回error code；
7. 去掉固定通道约定的明文/密文传输，改由分包cmd中的数据类型区分明文/密文传输；

### miwear-sdk-0.0.1 (2020.11.20)
1. v2新的绑定和登录;
2. 支持蓝牙传输多包分包的逻辑；
3. 获取beacon数据，注册GATT Service，GATT 传输等相关回调接口支持；
